export declare function executeGame();
export declare function getHighscore();
